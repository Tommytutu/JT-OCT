Submission package for Operations Research

Main manuscript source: main.tex
Compiled manuscript: manuscript.pdf
Bibliography database: references.bib
Prebuilt bibliography: main.bbl
INFORMS class/style files are included for portability.

Current organization:
1. Exact junction-tree formulation and polyhedral properties
2. Exact structural reductions
3. Exact solution algorithms and parallel evaluation
4. Computational study aligned with the three contributions

Current compiled length:
- Main paper including references: 26 pages
- Electronic Companion: 27 pages
- Total: 53 pages

The Electronic Companion contains proofs and selected supporting computational results. Low-level implementation settings, raw logs, commands, and validation artifacts are intended for the open-source project repository.

Compilation:
  pdflatex main.tex
  pdflatex main.tex

If references.bib is changed:
  pdflatex main.tex
  bibtex main
  pdflatex main.tex
  pdflatex main.tex
